#!/bin/bash
sudo apt install -y tree
rm -rf /tmp/folder
mkdir /tmp/folder
echo echo $(date) >> /tmp/folder/file1
sleep 2s
echo echo $(date) >> /tmp/folder/file1
sleep 2s
echo echo $(date) >> /tmp/folder/file1
sleep 2s
echo echo $(date) >> /tmp/folder/file1
sleep 2s
echo echo $(date) >> /tmp/folder/file1
sleep 2s
echo echo $(date) >> /tmp/folder/file1
sleep 2s
echo echo $(date) >> /tmp/folder/file2
sleep 2s
echo echo $(date) >> /tmp/folder/file3
sleep 2s
echo echo $(date) >> /tmp/folder/file4
